---
name: v3-generate-page
description: >-
  指导 AI 按本项目约定生成或改造页面：目录怎么放、组件如何拆分、TS/类型落点、报告页专项。
  当用户提到以下任何场景时都应触发：新建页面、生成页面、改页面结构、拆分组件、报告组件、页面目录、types 怎么放。
  即使用户没有明确说「生成页面」，只要意图是落地新页面或调整页面组织方式就应该使用此 Skill。
metadata:
  author: bao12New
  version: "2026.07.29"
---

# AI 页面生成指引

按本项目真实代码约定生成/改造页面。与用户需求冲突时以用户为准。

相关 Skill 分工见文末；命名与编码遵守 `.cursor/rules` 下 `vue.mdc` / `ts.mdc` / `project.mdc`。

## 1. 何时触发 / 输入要问清什么

触发后先确认（缺则主动问，一次 1–2 个关键项）：

1. **页面类型**：普通 CRUD / 登录落地 / 任务流 / 报告 / 其他
2. **落点路径**：`src/pages/<域>/<模块>/`（如 `system/user`、`resource/dataset`）
3. **是否已有 API**：`@@/apis/<module>` 与 `@@/apis/types/<module>` 是否已由 Swagger 生成
4. **是否要路由/菜单**：需要则委托 `v3-upsert-route`
5. **CRUD 字段**（若是列表页）：字段名、标签、类型、搜索/表单/表格各自是否出现

## 2. 页面类型判定

| 页面类型 | 典型路径 | 复杂度 | 模板 |
|---------|---------|--------|------|
| 普通 CRUD | `system/*`、`resource/*` | 低 | 单页 + Custom* → 细节用 `v3-create-crud` |
| 登录/落地 | `login/`、`home/` | 低 | 尽量单文件 + 可选 `types/` |
| 任务流 | `task/create`、`task/process` | 高 | `create/components` 分阶段 + dialogs/composables |
| 报告页 | `task/report` | 高 | 统一壳 + 场景分发 + `*Result`（见 §7） |

**原则：** 不要用 task/report 的目录复杂度去套 CRUD；也不要用 CRUD 单文件去硬塞报告。

## 3. 目录模板

### 3.1 普通业务页（默认）

```text
src/pages/<域>/<模块>/
├── index.vue           # 必需：页面入口
├── types/index.ts      # 常见：仅 UI/表单扩展类型
└── components/         # 可选：多面板/子列表时才拆
```

- 弹窗：**不建** `dialogs/`，用 `CustomDialog` 内联在 `index.vue`（或 Panel）
- 逻辑：CRUD 默认留在 `index.vue`，**不建** `composables/`
- API：**不建** `pages/.../apis/`，一律 `@@/apis/<module>`、`@@/apis/types/<module>`

### 3.2 复杂域页（task 级）

```text
src/pages/task/
├── create/
│   ├── index.vue
│   └── components/           # 创建+过程共用（原 flows）
│       ├── model/ | data/
│       ├── dialogs/
│       ├── composables/      # 创建表单 + MQTT/过程
│       ├── utils/            # 创建专用纯函数（如 parse-params-config）
│       ├── process/          # ProcessHeader、LoadingAnimation
│       └── styles/
├── process/index.vue         # 引用 create/components/*/Step
├── history/index.vue
├── report/                   # 见 §3.3
└── constants/                # 域根唯一共享（含路由 guard）
```

**不要**在 `task/` 根再建 `shared/`、`utils/`、`composables/`、`flows/`、`dialogs/`。镜像管理在 `pages/resource/image/`。

仅当跨多个子页面复用、或单文件明显过重时才拆这些目录。

### 3.3 报告页（专用）

```text
src/pages/task/report/
├── index.vue                 # 统一入口：拉数 + 壳布局
├── types/                    # 报告 UI/结果区类型
├── components/               # 壳层：Header、ModuleTabs
├── utils/                    # 适配/加载/mqtt/meta（过程页也可引用）
└── result/
    ├── index.vue             # 按 Method 查 preset → ConfigurableResult / GenericResult
    ├── presets/              # ★ 算法展示配置（新增算法只加这里）
    │   ├── types.ts
    │   ├── registry.ts
    │   └── *.ts              # 按评测维度拆分的 MethodPreset
    ├── components/           # ConfigurableResult + 原子 UI（StatCards/Table/Charts）
    ├── utils/                # flatten / preset-resolve
    ├── data/                 # 遗留 *Result（不再新加；未接入分发可忽略）
    └── model/                # 遗留模型 *Result（后续可迁入 presets）
```

**禁止：** 再新建按模块拆的独立路由页 `*Report.vue`（已废弃，路由统一进 `TaskReport`）。  
**禁止：** 为单个算法新建 `XxxResult.vue`（应加 `presets` 配置）。

## 4. 组件拆分 checklist

**该拆：**

- 被 ≥2 处复用的 UI 块
- 单一职责且模板/逻辑明显独立（如关联列表、字典多 Tab 面板）
- 报告：壳（Header/Tabs）vs 结果（`*Result`）vs 原子（`StatsGrid` 等）

**不该拆：**

- 只用一次的小片段（为拆而拆）
- 普通 CRUD 的搜索/表格/弹窗（用 Custom* 内联）
- 单模块结果页内部再强行拆「摘要/图表/样本」多页（可内聚在一个 `*Result.vue`）

## 5. 类型与 TS 落点

| 内容 | 落点 | 说明 |
|------|------|------|
| 接口实体、查询 SO、VO | `src/common/apis/types/<module>.ts` | Swagger 生成，**勿手改** |
| HTTP 方法 | `src/common/apis/<module>.ts` | 生成物；`import ... from '@@/apis/xxx'` |
| 页面表单扩展、分页壳、本地选项 | `pages/.../types/index.ts` | 可 `extends` API Entity |
| 报告展示契约（Tab、表列、统计项） | `report/types/` | 只服务报告 UI |
| 跨 create/process/report 的常量 | `pages/task/constants/` | 如 `REPORT_MODULES` |
| 报告数据适配/加载/mqtt | `pages/task/report/utils/` | adapter、load、build；过程页可引用 |
| 创建专用纯函数 | `create/components/utils/` | 如 `parse-params-config` |
| 结果区局部 hook | `report/result/composables/` | 仅 UI 样式/徽章逻辑 |

**边界一句话：** 后端契约进 `common/apis`；视图模型进 `pages/.../types`；报告数据工具进 `report/utils`；创建流程逻辑进 `create/components`；域常量进 `task/constants`。

默认一个 `types/index.ts`，不要按实体拆一堆小文件。拆文件门槛与写法见 `v3-ts-conventions`。

命名：

- 页面目录：kebab-case
- 组件文件：PascalCase（`index.vue` 除外）
- TS 文件：kebab-case
- composable：`useXxx` camelCase

## 6. UI 与依赖约定

- 列表/表单/弹窗/分页/Tab：优先 `@@/components` 的 `CustomTable` / `CustomForm` / `CustomDialog` / `CustomTabs` 等
- 图标：UnoCSS Iconify（`i-ep-*` / `i-fa-solid-*`），禁止 `@element-plus/icons-vue`（见 `iconify-icons`）
- 路径别名：`@` → `src`，`@@` → `src/common`
- 与旧文档/旧模板冲突时：**以 Custom* + 扁平 apis 为准**

## 7. 报告专项

```text
路由 TaskReport（/task/report）
  → report/index.vue（拉数 + 布局）
      → components/ReportHeader
      → components/ReportModuleTabs
      → result/index.vue（按 Method 查 presets/registry）
          → ConfigurableResult（命中 preset）或 GenericResult（兜底 JSON）
              → blocks：statCards / pie / bar / table / multiTable / splitBars / autoDetect / filePanel
      → report/utils + result/utils（适配与解析）
```

增量规则（配置驱动，不新建页面）：

1. 在 `result/presets/` 新增 `XxxPreset`（`metrics` + `blocks`）
2. 在 `result/presets/registry.ts` 的 `METHOD_PRESETS` 登记
3. 对照对接文档「§四 前端页面字段映射」核对字段与 format（`percent01` / `percent100`）
4. 跨算法可复用控件放 `result/components/`；禁止为单算法新建 `*Result.vue`
5. 未登记 Method 自动走 `GenericResult`，便于联调查看原始 JSON

## 8. 生成步骤与禁止事项

### 步骤

1. **判型** → 选目录模板（§2–§3）
2. **查已有** → `@@/apis`、路由、相近 Result/组件是否可复用
3. **最小落地** → 先 `index.vue`（+ 必要 `types/`）；再按需拆 `components/`
4. **CRUD 细节** → 委托 `v3-create-crud`
5. **报告增量** → 只加 `presets` + `registry` 登记，不新建独立报告路由 / `*Result.vue`
6. **路由** → 需要时走 `v3-upsert-route`
7. **Store / 工具** → 需要时走 `v3-upsert-store` / `v3-use-utils` / `v3-use-composables`
8. **类型写法** → `v3-ts-conventions`

### 禁止

- 手写一套 `el-table` + `el-form` + `el-dialog` 的 CRUD（应使用 Custom*）
- 在 `pages/` 下新建 `apis/`
- 手改 Swagger 生成的 `common/apis` / `common/apis/types`（缺接口应走生成脚本）
- 新建废弃形态的 `*Report.vue` 独立路由页
- 为单个算法新建 `*Result.vue`（应使用配置驱动 presets）
- 未经同意主动删除文件

## 9. 与其它 Skill 的分工

| Skill | 职责 |
|-------|------|
| **本 Skill（v3-generate-page）** | 总纲：判型、目录、拆分、TS 落点、报告约定 |
| `v3-ts-conventions` | 类型怎么写、放哪、何时拆文件 |
| `v3-create-crud` | CRUD 页实现细节（Custom*、字段、增删改查逻辑） |
| `v3-upsert-route` | 路由 / 菜单 |
| `v3-upsert-store` | Pinia Store |
| `v3-use-utils` | `@@/utils` |
| `v3-use-composables` | `@@/composables` |
| `iconify-icons` | 图标类名 |
| `element-plus-vue3` | Element Plus 细节 |
