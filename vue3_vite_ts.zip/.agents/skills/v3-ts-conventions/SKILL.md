---
name: v3-ts-conventions
description: >-
  本项目 TypeScript 约定：类型落点、命名、拆文件门槛、与 Swagger 生成类型的边界。
  当用户提到以下任何场景时都应触发：写 TS、定义类型、types 放哪、interface vs type、enum、
  页面 types、any、import type。即使用户没有明确说 TypeScript，只要在新增字段、表单、
  API 实体或组件 Props 时需要落类型，就应使用此 Skill。
metadata:
  author: bao12New
  version: "2026.08.24"
---

# TypeScript 约定

按本仓库真实代码写类型。不要套全局 `src/types/`、不要 `I` 前缀。目录总纲见 `v3-generate-page`。

## 1. 原则

- **谁拥有数据，类型就跟谁走**；不要先抽公共再写业务
- 后端契约只来自 `@@/apis/types`；页面只放视图模型
- **类型文件宜少不宜碎**：默认一个 `types/index.ts`（或模块旁一个 `types.ts`）

## 2. 落点

| 内容 | 落点 | 说明 |
|------|------|------|
| 接口实体、查询 SO、VO | `src/common/apis/types/<module>.ts` | Swagger 生成，**勿手改** |
| HTTP 方法 | `src/common/apis/<module>.ts` | `import ... from "@@/apis/xxx"` |
| 手写适配契约（如登录） | `src/common/apis/types/auth.ts` 等独立文件 | 非生成区才可手写 |
| 页面表单 / 查询 / 表格行扩展 | `src/pages/<域>/<模块>/types/index.ts` | 可 `extends` API 实体 |
| 通用组件 / layout / store | 模块旁 `types.ts` | 对外从 `api.ts` 再导出 |
| 只被一个组件用的三四行类型 | 写在该 `.vue` 里 | 不要为它建文件 |

**禁止：**

- 新建全局 `src/types/`、`types/common.ts`、`types/api.ts` 大仓库
- 在 `pages/` 下新建 `apis/` 或复制一份后端实体
- 手改 `src/common/apis` / `src/common/apis/types` 的生成区（缺字段走 `pnpm api:generate`）

仅当 **≥2 个无关模块** 都要用时，才升到 `src/common`（utils / composables / components）。

## 3. 拆文件门槛

默认 **不拆**。复杂页也先挤在 `types/index.ts`。

| 情况 | 做法 |
|------|------|
| 单文件小于约 150～200 行，主题还能凑在一起 | **不拆** |
| 超过该量，或明显两坨互不相关（如报告「壳」vs「结果」） | 按 **主题** 拆 2～4 个文件 |
| 某个类型只服务一个 `.vue` 且很短 | 留在组件内 |
| 只为目录对称 | **禁止** |

拆的是主题，不是实体：

- 可以：`types/form.ts`、`types/result.ts`
- 不要：`user.ts` + `user-form.ts` + `user-query.ts` + `user-table.ts`

拆完必须由 `types/index.ts` 再导出；页面只 `from "./types"`，不要满项目 `from "./types/form"`。

复杂页优先拆 `components/` / `composables/` / `utils/`，类型跟着边界走即可。

## 4. 命名

- 类型名 PascalCase：`ArticleItem`、`LoginInput`、`TableColumn`
- **不用** `IUser`、`UserType` 等匈牙利命名
- 文件：页面 `types/index.ts`；模块旁 `types.ts`；其余 TS 文件 kebab-case
- 字面量联合优先于 `enum`：`status: "draft" | "published"`
- 需要运行时对象时用 `as const` + 派生类型，而不是为了类型去写 `enum`
- 组件 Props 泛型默认 `Record<string, unknown>`，不要 `any`

CRUD 页常见三件套（参考 `src/pages/demo/article/types/index.ts`）：

- `XxxItem` / 实体行
- `XxxFormData`（编辑时 `id?`）
- `XxxQuery`（搜索；空选项可用 `"" | "draft" | ...`）

## 5. 写法

- 对象形状用 `interface`；联合、交叉、工具类型用 `type`
- 只做类型导入：`import type { Foo } from "..."`
- 能推断就不写注解；函数入参、导出 API、Props / Emits 要写清
- 容器才显式标：`ref<ArticleItem[]>([])`
- 扩展 API 实体，不要拷贝字段：

```ts
import type { UserEntity } from "@@/apis/types/user"

export interface UserFormData extends UserEntity {
  password?: string
}
```

- 避免 `any`：用 `unknown` 再收窄；搜索参数不要 `as any`
- 禁止 `@ts-ignore`；必要时 `@ts-expect-error` 并写一行原因
- 不要自写 `Pick` / `Omit` / `DeepPartial`（用 TS 内置或现有工具）

## 6. 与其它 Skill

| Skill | 职责 |
|-------|------|
| **本 Skill** | 类型怎么写、放哪、何时拆文件 |
| `v3-generate-page` | 页面目录、组件拆分、报告结构（含类型落点表） |
| `v3-create-crud` | CRUD 页字段与 Custom* 实现 |
| `v3-upsert-store` | Pinia state / 类型 |
