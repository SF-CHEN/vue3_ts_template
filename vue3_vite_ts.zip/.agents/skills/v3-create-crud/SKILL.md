---
name: v3-create-crud
description: >-
  创建增删改查（CRUD）页面，基于 CustomTable / CustomForm / CustomDialog 与 Element Plus，
  包含表格、搜索、分页、新增/编辑弹窗、删除确认等功能。
  当用户提到以下任何场景时都应触发：创建管理页面、创建列表页、创建表格页。
  即使用户没有明确说 CRUD，只要意图是创建带表格和表单操作的后台页面就应该使用此 Skill。
  使用时需提供模块名称和字段信息。目录与拆分总纲见 v3-generate-page。
metadata:
  author: Glittering Ma & pany
  version: "2026.07.29"
---

# 创建 CRUD 页面

根据用户提供的模块名称和字段信息，生成增删改查页面。

本 Skill 定义默认 CRUD 模式；与用户需求冲突时以用户为准。目录/拆分/TS 总纲见 `v3-generate-page`。

## 输入要求

用户需提供：

1. **模块名称**（如 `product`、`order`）— 用于目录名和命名
2. **页面路径**（如 `system/user`、`resource/dataset`）
3. **字段列表** — 每个字段需明确：
   - 字段名（英文，camelCase）
   - 中文标签
   - 类型（string / number / boolean / enum / date 等）
   - 是否必填
   - 是否作为搜索条件
   - 是否需要自定义渲染（如 tag 状态展示）

信息不完整时主动询问补全后再生成。

## 生成文件

1. `src/pages/<域>/<模块>/index.vue` — 页面主文件
2. `src/pages/<域>/<模块>/types/index.ts` — 页面 UI 扩展类型（`XxxItem`、`XxxFormData`、`XxxQuery` 等；拆文件门槛见 `v3-ts-conventions`）
3. 可选：`src/pages/<域>/<模块>/components/*.vue` — 仅多面板/子列表时拆

接口与实体类型：

- 优先使用已有生成物：`@@/apis/<module>`、`@@/apis/types/<module>`
- **不要**在 `pages/` 下新建 `apis/`
- **不要**手改 `src/common/apis/<module>.ts` / `src/common/apis/types/<module>.ts`；缺接口时走 Swagger 生成脚本
- 扁平结构：`src/common/apis/<module>.ts` + `src/common/apis/types/<module>.ts`（不是 `apis/<module>/index.ts` + `type.ts`）

## 设计决策指引

**弹窗宽度** — 默认 `550px`，复杂布局用更大宽度。

**工具栏按钮** — 按需组合：

- 「新增」几乎总是需要
- 「批量删除」仅在有批量需求时添加
- 「下载/导出」仅在有导出需求时添加

**删除确认文案** — 用对用户最有辨识度的字段（用户名、名称等），而不是裸 id。

**搜索参数** — 保持简单，避免 `as any`；字段多时用 `entity: { ...searchData }` 展开。

**表单字段 vs 表格列**：

- 仅创建时需要的字段（如密码）：表单有、表格无；用 `showFn` 或条件控制
- 系统生成字段（如创建时间）：表格有、表单无

## 页面结构规范

页面包裹在 `<div class="app-container page-card">`，优先使用：

- `CustomTable` — 表格 + 分页
- `CustomForm` — schema 驱动表单
- `CustomDialog` — 新增/编辑弹窗
- 可选 `CustomTabs` — 多 Tab 列表

**禁止**为 CRUD 手写一整套 `el-table` + `el-form` + `el-dialog`（局部展示可用 `el-*`）。

参考实现：`src/pages/system/user/index.vue`。

### 典型模板骨架

```vue
<template>
  <div v-loading="loading" class="app-container page-card">
    <div class="toolbar">
      <el-button type="primary" @click="handleCreate">
        <template #icon>
          <span class="i-ep-plus" />
        </template>
        新增
      </el-button>
    </div>

    <CustomTable
      :data="tableData"
      :columns="columns"
      v-model:pagination="pagination"
      @pagination="getTableData"
    />

    <CustomDialog
      v-model="dialogVisible"
      :title="formData.id === undefined ? '新增' : '编辑'"
      width="550px"
      :loading="loading"
      @confirm="handleCreateOrUpdate"
      @closed="resetForm"
    >
      <CustomForm
        ref="formRef"
        :form="formData as Record<string, unknown>"
        :schema="formSchema"
        label-width="110px"
        label-position="left"
      />
    </CustomDialog>
  </div>
</template>
```

图标用 UnoCSS（`i-ep-*`），禁止 `@element-plus/icons-vue`。详见 `iconify-icons`。

## 代码组织规范

使用 `<script lang="ts" setup>` + `defineOptions({ name: "PascalCase 页面名" })`。

顶部声明 `loading`、`pagination`（`TablePagination`）、`tableData`、`dialogVisible`、`formData`。

列表请求统一走 `getTableData`；搜索时重置 `pageCurrent = 1`。

### 增（Create）/ 改（Update）

```ts
const DEFAULT_FORM_DATA: XxxFormData = {
  id: undefined,
  // ... 表单初始值
}

const formSchema = computed<FormSchemaItem[]>(() => [
  { prop: "name", label: "名称", type: "input", rule: true, ruleMessage: "请输入名称", trigger: "blur" }
  // ...
])

const columns = computed<TableColumn<Entity>[]>(() => [
  { prop: "name", label: "名称" },
  {
    type: "operation",
    label: "操作",
    width: 200,
    fixed: "right",
    buttons: [
      { label: "编辑", type: "warning", plain: true, onClick: row => handleUpdate(row as Entity) },
      { label: "删除", type: "danger", plain: true, onClick: row => handleDelete(row as Entity) }
    ]
  }
])

function handleCreate() {
  formData.value = cloneDeep(DEFAULT_FORM_DATA)
  dialogVisible.value = true
}

function handleUpdate(row: Entity) {
  formData.value = cloneDeep(row) as XxxFormData
  dialogVisible.value = true
}

async function handleCreateOrUpdate() {
  try {
    await formRef.value?.validate()
  } catch {
    ElMessage.error("表单校验不通过")
    return
  }
  loading.value = true
  const api = formData.value.id === undefined ? addXxx : updateXxx
  api(/* submit payload */).then(() => {
    ElMessage.success(formData.value.id === undefined ? "新增成功" : "修改成功")
    dialogVisible.value = false
  }).finally(() => {
    loading.value = false
    getTableData()
  })
}

function resetForm() {
  formRef.value?.clearValidate()
  formData.value = cloneDeep(DEFAULT_FORM_DATA)
}
```

新增和编辑共用一个弹窗，用 `id === undefined` 区分。编辑时用 `cloneDeep`，避免污染表格行。

### 删（Delete）

```ts
function handleDelete(row: Entity) {
  if (row.id === undefined) return
  ElMessageBox.confirm(`确认删除「${row.辨识字段}」吗？`, "系统提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning"
  }).then(() => {
    loading.value = true
    deleteXxx({ id: row.id! }).then(() => {
      ElMessage.success("删除成功")
    }).finally(() => {
      loading.value = false
      getTableData()
    })
  })
}
```

### 查（Read）

```ts
const pagination = reactive<TablePagination>({
  pageCurrent: 1,
  pageSize: 10,
  total: 0
})

function getTableData() {
  loading.value = true
  pageXxx({
    pageCurrent: Number(pagination.pageCurrent || 1),
    pageSize: Number(pagination.pageSize || 10),
    entity: { /* ...searchData */ }
  }).then((res) => {
    const { data } = res as unknown as ApiResponseData<PageEntity>
    pagination.total = data?.total ?? 0
    tableData.value = data?.records ?? []
  }).catch(() => {
    tableData.value = []
  }).finally(() => {
    loading.value = false
  })
}

onMounted(getTableData)
```

分页由 `CustomTable` 的 `v-model:pagination` + `@pagination` 驱动。

## CustomForm schema 字段类型

| 字段语义 | `type` | 备注 |
|---------|--------|------|
| 短文本 | `input` | |
| 长文本 | `input` + `typeProps: { type: "textarea" }` | |
| 密码 | `input` + `typeProps: { type: "password", showPassword: true }` | |
| 数字 | `input-number` 或按组件支持类型 | 设 min/max |
| 开关 | `switch` | |
| 枚举 | `select` | 搜索区加 clearable |
| 日期/区间 | `date` + `typeProps` | `valueFormat` 与后端对齐 |

校验：`rule` / `ruleMessage` / `trigger` / 自定义 `validator` / `showFn`。

## 类型规范（页面 types）

在 `pages/.../types/index.ts`：

```ts
import type { Entity } from "@@/apis/types/<module>"

/** 分页结果（生成物未单独导出时与后端结构对齐） */
export interface PageEntity {
  records?: Entity[]
  total?: number
}

/** 表单扩展：仅 UI 需要的字段 */
export interface XxxFormData extends Entity {
  // 例如确认密码、日期区间等
}
```

后端实体 / SO / VO 从 `@@/apis/types/<module>` 导入，**不要**在页面 types 里重复定义契约字段。

## 导入规范

```ts
import type { Entity, PageQuerySoEntity } from "@@/apis/types/<module>"
import type { FormSchemaItem } from "@@/components/CustomForm/types"
import type { TableColumn, TablePagination } from "@@/components/CustomTable/types"
import type { PageEntity, XxxFormData } from "./types"
import { addXxx, deleteXxx, pageXxx, updateXxx } from "@@/apis/<module>"
import CustomDialog from "@@/components/CustomDialog/index.vue"
import CustomForm from "@@/components/CustomForm/index.vue"
import CustomTable from "@@/components/CustomTable/index.vue"
import { cloneDeep } from "lodash-es"
```

以下为自动导入，无需手动引入：`ElMessage`、`ElMessageBox`、`ref`、`reactive`、`computed`、`onMounted`、`useTemplateRef`。

## 样式规范

```scss
.toolbar {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 12px;
}
```

使用 `<style lang="scss" scoped>`。

## 命名约定

模块名为 `product`、页面在 `resource/product` 时：

| 位置 | 命名 |
|------|------|
| 页面目录 | `src/pages/resource/product/` |
| 接口文件 | `src/common/apis/product.ts` |
| 类型文件 | `src/common/apis/types/product.ts` |
| 组件 name | `ResourceProduct`（或与路由 name 一致） |
| API 函数 | 以生成物为准（如 `pageProduct`、`addProduct`） |
| 页面引用 | `@@/apis/product`、`@@/apis/types/product` |

## 路由提示

生成代码后，若尚无路由，委托 `v3-upsert-route` 添加对应路由/菜单。
