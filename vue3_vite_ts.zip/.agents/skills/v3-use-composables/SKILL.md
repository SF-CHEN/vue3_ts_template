---
name: v3-use-composables
description: 项目内置组合式函数使用教程，涵盖设备检测、路由监听、动态标题、水印、灰色/色弱模式等。当用户提到组合式函数、Composables、判断设备类型、监听路由变化、设置页面标题、添加水印等场景时触发。
metadata:
  author: pany
  version: "2026.07.29"
---

# 内置组合式函数使用教程

项目在 `src/common/composables` 目录下提供了一组通用组合式函数，通过路径别名 `@@/composables/` 导入。

本 Skill 定义的是项目内置的组合式函数，当这些函数不存在时，以用户需求为准，新增对应函数。

当前可用：`useDevice`、`useRouteListener`、`useTitle`、`useWatermark`、`useGreyAndColorWeakness`。

分页请直接使用页面内 `reactive({ pageCurrent, pageSize, total })` 或 `CustomTable` 的 `useTablePagination`，不要依赖已移除的 `usePagination`。

## 设备检测 `useDevice`

判断当前设备类型（移动端 / 桌面端），基于 `appStore.device` 的响应式计算属性。

```ts
import { useDevice } from "@@/composables/useDevice"

const { isMobile, isDesktop } = useDevice()

// 在模板或逻辑中使用
if (isMobile.value) {
  // 移动端逻辑
}
```

## 路由监听 `useRouteListener`

基于发布订阅模式监听路由变化，比直接 `watch` 路由性能更好，组件卸载时自动移除监听。

```ts
import { useRouteListener } from "@@/composables/useRouteListener"

const { listenerRouteChange, removeRouteListener } = useRouteListener()

// 监听路由变化
listenerRouteChange((route) => {
  console.log("路由变化了:", route.path)
})

// 立即执行一次（获取当前路由信息）
listenerRouteChange((route) => {
  activeMenu.value = route.path
}, true) // 第二个参数 immediate = true
```

## 动态标题 `useTitle`

动态设置浏览器标签页标题，格式为 `项目名 | 页面名`。

```ts
import { useTitle } from "@@/composables/useTitle"

const { setTitle } = useTitle()

// 设置标题为 "V3 Admin Vite | 用户管理"
setTitle("用户管理")

// 重置为项目默认标题
setTitle()
```

## 水印 `useWatermark`

为页面或指定容器添加水印，支持防御（防止用户通过控制台删除或隐藏水印），组件卸载时自动清除。

```ts
import { useWatermark } from "@@/composables/useWatermark"

// 默认挂载到 body
const { setWatermark, clearWatermark } = useWatermark()

// 设置水印
setWatermark("机密文件")

// 自定义配置
setWatermark("内部使用", {
  defense: true,    // 开启防御（默认 true）
  color: "#c0c4cc", // 文本颜色
  opacity: 0.5,     // 透明度
  size: 16,         // 字体大小
  angle: -20,       // 倾斜角度
  width: 300,       // 单个水印宽度（越大密度越低）
  height: 200       // 单个水印高度（越大密度越低）
})

// 清除水印
clearWatermark()
```

挂载到指定容器：

```vue
<script setup lang="ts">
import { useWatermark } from "@@/composables/useWatermark"

const localRef = useTemplateRef("localRef")
const { setWatermark, clearWatermark } = useWatermark(localRef)

onMounted(() => {
  setWatermark("仅限内部")
})
</script>

<template>
  <div ref="localRef">
    <!-- 内容 -->
  </div>
</template>
```

## 灰色模式与色弱模式 `useGreyAndColorWeakness`

初始化灰色模式和色弱模式，基于 `settingsStore` 的配置自动切换 HTML 根元素的 CSS 类名。

```ts
import { useGreyAndColorWeakness } from "@@/composables/useGreyAndColorWeakness"

const { initGreyAndColorWeakness } = useGreyAndColorWeakness()

// 应用启动时调用一次即可，后续会自动响应 Store 变化
initGreyAndColorWeakness()
```

## 使用原则

1. 优先使用这些内置组合式函数，不要重复造轮子
2. 组合式函数内部已处理生命周期（如 `onBeforeUnmount` 自动清理），无需手动管理
3. 需要新增通用组合式函数时，在 `src/common/composables` 目录下创建，命名以 `use` 开头
4. 页面私有的组合式函数应放在对应页面目录的 `composables` 子目录下，而非 `src/common/composables`
