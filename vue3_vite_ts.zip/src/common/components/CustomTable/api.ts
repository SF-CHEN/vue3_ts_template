import "./registry/builtInTypes"

export { default as CustomTable } from "./index.vue"
export {
  getColumnType,
  getRegisteredColumnTypes,
  hasColumnType,
  registerColumnType
} from "./registry"
export type {
  ColumnTypeConfig,
  TableColumn,
  TableOperationButton,
  TablePagination,
  TablePaginationKeys
} from "./types"
