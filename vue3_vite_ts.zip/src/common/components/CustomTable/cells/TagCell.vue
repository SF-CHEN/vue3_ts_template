<script lang="ts" setup>
import type { TableColumn } from "../types"
import { computed } from "vue"

const props = withDefaults(defineProps<{
  column: TableColumn
  row: Record<string, unknown>
  value?: string | number | boolean
  emptyText?: string
}>(), {
  emptyText: "-"
})

const label = computed(() => {
  if (typeof props.column.formatter === "function") {
    return props.column.formatter(props.value, props.row, props.column)
  }
  if (props.value || props.value === 0) return props.value
  return props.emptyText
})

const tagType = computed(() => {
  if (typeof props.column.tagType === "function") {
    return props.column.tagType(props.value, props.row)
  }
  return props.column.tagType
})
</script>

<template>
  <el-tag v-if="tagType" :type="tagType as any" v-bind="column.tagProps">
    {{ label }}
  </el-tag>
  <span v-else>{{ label }}</span>
</template>
