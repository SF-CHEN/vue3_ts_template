<script lang="ts" setup>
import type { TableColumn, TableOperationButton } from "../types"
import { computed } from "vue"

const props = defineProps<{
  column: TableColumn
  row: Record<string, unknown>
}>()

const visibleButtons = computed(() =>
  ((props.column.buttons || []) as TableOperationButton[]).filter((btn) => {
    if (typeof btn.show === "function") return btn.show(props.row)
    return btn.show !== false
  })
)
</script>

<template>
  <div class="operation-cell">
    <el-button
      v-for="(btn, index) in visibleButtons"
      :key="index"
      :type="btn.type || 'primary'"
      :size="btn.size || 'default'"
      :plain="btn.plain"
      :link="btn.link"
      v-bind="btn.props"
      @click="btn.onClick?.(row, column)"
    >
      {{ btn.label }}
    </el-button>
  </div>
</template>

<style lang="scss" scoped>
.operation-cell {
  display: flex;
  flex-wrap: wrap;
}
</style>
