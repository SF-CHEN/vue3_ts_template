<script lang="ts" setup>
import type { TableColumn } from "../types"
import { computed } from "vue"

const props = withDefaults(defineProps<{
  column: TableColumn
  row: Record<string, unknown>
  value?: string | number | boolean
  emptyText?: string
}>(), {
  emptyText: "-"
})

const displayText = computed(() => {
  if (typeof props.column.formatter === "function") {
    return props.column.formatter(props.value, props.row, props.column)
  }
  if (props.value || props.value === 0) {
    return props.value
  }
  return props.emptyText
})
</script>

<template>
  <span>{{ displayText }}</span>
</template>
