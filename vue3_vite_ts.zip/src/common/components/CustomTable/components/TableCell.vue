<script lang="ts" setup>
import type { TableColumn } from "../types"
import { computed } from "vue"
import { getColumnType } from "../registry"

const props = withDefaults(defineProps<{
  column: TableColumn
  row: Record<string, unknown>
  emptyText?: string
}>(), {
  emptyText: "-"
})

const cellValue = computed(() => {
  if (!props.column.prop) return undefined
  return props.row[props.column.prop]
})

const cellComponent = computed(() => {
  const type = props.column.render || props.column.type || "text"
  if (["index", "selection", "expand"].includes(type)) return null
  return getColumnType(type)?.component ?? getColumnType("text")?.component
})
</script>

<template>
  <component
    :is="cellComponent"
    v-if="cellComponent"
    :column="column"
    :row="row"
    :value="cellValue"
    :empty-text="emptyText"
  />
</template>
