import type { ColumnTypeConfig } from "../types"
import { markRaw } from "vue"

const columnTypeRegistry = new Map<string, ColumnTypeConfig>()

/** 注册表格列渲染类型 */
export function registerColumnType(type: string, config: ColumnTypeConfig) {
  if (!type || !config?.component) {
    console.warn("[CustomTable] registerColumnType: type 与 component 为必填项")
    return
  }
  columnTypeRegistry.set(type, {
    ...config,
    component: markRaw(config.component)
  })
}

export function getColumnType(type: string) {
  return columnTypeRegistry.get(type)
}

export function hasColumnType(type: string) {
  return columnTypeRegistry.has(type)
}

export function getRegisteredColumnTypes() {
  return [...columnTypeRegistry.keys()]
}
