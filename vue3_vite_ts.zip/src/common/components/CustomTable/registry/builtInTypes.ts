import OperationCell from "../cells/OperationCell.vue"
import TagCell from "../cells/TagCell.vue"
import TextCell from "../cells/TextCell.vue"
import { registerColumnType } from "./index"

const builtInColumnTypes = {
  text: TextCell,
  tag: TagCell,
  operation: OperationCell
}

Object.entries(builtInColumnTypes).forEach(([type, component]) => {
  registerColumnType(type, { component })
})

export { builtInColumnTypes }
