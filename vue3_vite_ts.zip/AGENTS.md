## 原则

- 用最少的代码解决问题，不要过度抽象
- 不添加未要求的功能或“以防万一”的配置
- 业务页面放 `src/pages`，通用能力放 `src/common`

## 命令

```bash
pnpm i
pnpm run init -- -ProjectTitle 中文标题
pnpm dev
pnpm typecheck
pnpm lint
pnpm test
pnpm build
pnpm api:generate   # Swagger → API / 类型 / enums
pnpm api:doc
```

## 技术栈

Vue 3 · Vite · TypeScript · Element Plus · Pinia · Vue Router · UnoCSS

## 目录

- `src/common/apis`：接口（手写 auth / demo + Swagger 生成模块）
- `src/common/apis/types`：Swagger 契约类型（勿手改生成区）
- `src/common/components`：CustomTable / CustomForm / CustomDialog 等
  - 根目录：`index.vue`（组件）、`types.ts`（类型）、`api.ts`（对外 barrel）
  - `components/`：内部调度器（FormField / FormItemWrapper / TableCell）
  - `registry/`：类型注册表 + 内置类型；扩展时从 `api.ts` 取 `registerFormType` / `registerColumnType`，勿深挖内部
  - `fields/` / `cells/`：具体渲染实现
- `src/layouts`：后台布局
- `src/pages`：页面（`demo` 为示例 CRUD）
- `src/router`：常驻路由 + 动态权限路由
- `src/pinia`：状态
- `script`：init + Swagger 拉取 / 生成

## 约定

- 新增业务页：目录 → 路由 → API →（可选）Store
- 业务接口优先 `pnpm api:generate`；手写适配层放独立文件（如 `auth.ts`）
- 换后端：改 `src/common/apis/auth.ts`、`src/http/axios.ts`，并配置 `SWAGGER_URL`
- 演示账号：`admin` / `user`，密码任意（Mock 模式）
- 模板发版：更新 `package.json` version + `CHANGELOG.md`；升级说明见 `docs/UPGRADE.md`

## TypeScript

- 后端实体 / SO / VO：`src/common/apis/types`（生成区，勿手改）
- 页面表单、查询、本地选项：`src/pages/<域>/<模块>/types/index.ts`
- 通用组件 / layout / store：模块旁 `types.ts`，从 `api.ts` 对外导出
- 禁止新建全局 `src/types/`；禁止在 `pages/` 下手写 API 类型
- 默认一个 types 文件；约 150～200 行或主题明显分裂时再按主题拆，并由 `index.ts` 再导出
- 对象形状用 `interface`，联合/工具类型用 `type`；不用 `I` 前缀
- 只做类型导入用 `import type`；避免 `any`，用 `unknown` + 收窄
- 细则见 `.agents/skills/v3-ts-conventions/SKILL.md`
